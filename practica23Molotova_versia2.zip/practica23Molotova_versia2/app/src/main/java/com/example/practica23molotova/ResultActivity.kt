package com.example.practica23molotova

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.practica23molotova.databinding.ActivityResultBinding


class ResultActivity : Activity() {

    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    fun take_result(view: View) {
        Toast.makeText(this, "Succes", Toast.LENGTH_SHORT).show()
    }
}