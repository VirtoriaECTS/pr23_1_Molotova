package com.example.practica23molotova

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.wearable.activity.WearableActivity
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.example.practica23molotova.databinding.ActivitySignInBinding
import com.google.android.gms.wearable.Wearable

class SignInActivity : WearableActivity() {

    private lateinit var binding: ActivitySignInBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
fun notification(text:String){
    Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
    fun signIn(view: View) {
        val emailText: EditText= findViewById(R.id.email)
        val passwordText: EditText = findViewById(R.id.password)

        if(emailText.text.isNotEmpty() && passwordText.text.isNotEmpty()){
            notification("Sucess")
            val intent = Intent(this, ResultActivity::class.java)
            startActivity(intent)
        }
        else{
            notification("Enter login and password")
        }

    }
}